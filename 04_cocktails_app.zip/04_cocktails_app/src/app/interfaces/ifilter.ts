export interface IFilter {
    'searchBy': string,
    'value': string

}
